/***************************************************
 로딩중 뺑뺑이화면 제어
***************************************************/
function setLoading(bVal) {
	var oDv = document.getElementById("dvLoading");
	var oDv2 = document.getElementById("dvLoadingImg");
	if(!oDv) {
		oDv = document.createElement("DIV");
		oDv.id = "dvLoading";
		document.body.appendChild(oDv);
	}
	if(!oDv2) {
		oDv2 = document.createElement("DIV");
		oDv2.id = "dvLoadingImg";
		var oImg = document.createElement("IMG");
		oImg.src = "/images/ajax-loader.gif";
		oDv2.appendChild(oImg);
		document.body.appendChild(oDv2);
	}

	var $Dv  = $(oDv);
	var $Dv2 = $(oDv2);
	var sDisplay = (bVal ? "block" : "none");

	$Dv.css({
		"display" : sDisplay
	});
	$Dv2.css({
		"display" : sDisplay
	});

	//console.log("setloading(" + bVal + ")");
}

/******************************************
  windowOpenForm 함수를 호출하기위해 정의
   - 이 함수로 popup을 열어야, popCloseAll 함수 수행시 자동종료가 가능하다
******************************************/
function windowOpenFormCommon(oFrm, nWidth, nHeight, oOpt) {
	if(!window.oPopup) { //팝업객체 생성
		window.oPopup = {};
	}
	oOpt = oOpt || ("defaultStatus=no,menubar=no,status=no,scrollbars=yes,resizable=yes");
	oPopup[oFrm.target] = windowOpenForm(oFrm, nWidth, nHeight, oOpt);
}


/***************************************************
 form객체로 window.open 수행하기
----------------------------------------------------
oFrm       : 전달할 폼객체
nWidth     : 사이즈
nHEight    : 폭
sEtcOption : 기타옵션
***************************************************/
function windowOpenForm(oForm, nWidth, nHeight, sEtcOption) {
	var oWin;
	var sTarget = oForm.target;
	var sOption = "width=" + nWidth + ",height=" + nHeight;

	if(sEtcOption)
		sOption += "," + sEtcOption;

	oWin = window.open("about:blank", sTarget, sOption);
	oForm.submit();
	return oWin;
}

/******************************************
  열려있는 팝업 모두 닫기
******************************************/
function popCloseAll() {
	if(window.oPopup) {
		for(var v in oPopup) {
			try {
				oPopup[v].window.close();
			}
			catch (err) {
			}
		}
	}
}



/***************************************************
 Shell 명령어 실행
----------------------------------------------------
 - IE계열만 가능.
***************************************************/
function runLocalExec(sScript) {
	var sAgent = navigator.userAgent.toLowerCase();

	if(sAgent.indexOf("chrome") != -1) {
		prompt("CTRL + R", sScript);
	}
	else {
		var oShell = new ActiveXObject("WScript.Shell");
		oShell.Run(sScript, 1, false);
	}
}

/*****************************************
 객체형 데이터를 serialize함(url 키=값 쌍)
 -----------------------------------------
 기본값 : encodeuriComponent
*****************************************/
function serializeParam(oParam, sEncodeType) {
	var sStr = "";
	for(var v in oParam) {
		var sValue = oParam[v];
		if(sStr != "")
			sStr += "&";
		sStr = sStr + v + "=";
		switch(sEncodeType)
		{
			case "escape":
				sStr += escape(oParam[v]);
				break;
			case "utf-8":
				sStr += encodeURIComponent(oParam[v]);
				break;
			default: //인코딩안함
				sStr += oParam[v];
				break;
		}
	}
	return sStr;
}

/*****************************************
 url형 데이터를 parallel함(url 키=값 쌍)
*****************************************/
function parallelizeParam(sString, sEncodeType) {
	var oReturn = {};
	var aParams = sString.split("&");//&문자열로 쪼갬
	for(var i=0; i<aParams.length; i++) {
		var aTmp = aParams[i].split("=");
		switch(sEncodeType) {
			case "escape":
				aTmp[1] = unescape(aTmp[1]);
				break;
			case "utf-8":
				aTmp[1] = decodeURIComponent(aTmp[1]);
				break;
			default: //인코딩안함
				aTmp[1] = aTmp[1];
				break;
		}
		oReturn[aTmp[0]] = aTmp[1];
	}
	return oReturn;
}

/******************************************
  URL root 리턴(포트포함)
******************************************/
function getUrlRoot() {
	var sRoot = window.location.protocol + "//" + window.location.hostname
	if(window.location.port != "") {
		sRoot += ":" + window.location.port;
	}
	return sRoot;
}

/***************************************************
 sBase 내에 sSpl 구분자를 기준으로하여 sFind가 존재하는지 여부 확인
***************************************************/
function hasValue(sBase, sFind, sSpl) {
	sSpl = sSpl || ",";
	var oReg = new RegExp("(^|" + sSpl + ")" + sFind + "($|" + sSpl + ")");
	return oReg.test(sBase);
}






/*****************************************
 파일명 스트링에서 확장자만 리턴함(소문자로 리턴)
*****************************************/
function getFileExt(sFileName) {
	var sExt = "";
	if(sFileName.indexOf(".") >= 0) {
		var aTmp = sFileName.split(".");
		sExt = aTmp[aTmp.length - 1];
	}
	return sExt.toLowerCase();
}

/*****************************************
 파일명 스트링에서 파일명만 리턴함
*****************************************/
function getFileNameOnly(sFullPath) {
	sFullPath = sFullPath.replace(/\//gi, "\\"); // 일단 드라이브경로로 치환
	var aTmp = sFullPath.split("\\");
	return aTmp[aTmp.length - 1];
}
/******************************************
  FTP 베이스 연결스트링 생성(공통으로사용하기 위해서)
******************************************/
function getFTPServerInfoHTML(oConInfo) {
	var sReturn = "";
	if(oConInfo != undefined) {
		if(oConInfo.contype == "FTP") {//FTP인경우 에만 별도로 생성하면 된다
			sReturn = oConInfo.ftp_id + "@" + oConInfo.ftp_ip + ":" + oConInfo.ftp_port;
		}
	}

	return sReturn;
}
/******************************************
  서버연결정보를 토대로하여, fullpath구하기
******************************************/
function getFullPathByServerInfo(sFilePath, oServerInfo) {
	var sFullPath = "";
	var sPreFix = "";
	sPreFix = getFullRootByServerInfo(oServerInfo);
	sFullPath = sPreFix + sFilePath;
	return sFullPath
}
/******************************************
  서버정보로 root경로문자 생성하여 리턴
******************************************/
function getFullRootByServerInfo(oServerInfo) {
	var sFullRoot = "";
	switch(oServerInfo.contype) {
		case "LOCAL":
			sFullRoot = oServerInfo.local_drive + ":";
			break;
		case "NET":
			sFullRoot = oServerInfo.net_drive + ":";
			break;
		case "UNC":
			sFullRoot = oServerInfo.unc_uncroot;
			break;
		case "FTP":
			sFullRoot = "ftp://" + oServerInfo.ftp_id + "@" + oServerInfo.ftp_ip + ":" + oServerInfo.ftp_port;
			break;
		default:
			return "undefined";
			break;
	}
	if(oServerInfo.root && oServerInfo.root != "\\") {
		sFullRoot += oServerInfo.root;
	}

	return sFullRoot;
}


/*****************************************
 BASE64 인/디코딩
*****************************************/
var Base64 = {
	// public property
	_keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", //BASE64 인코딩문자열
	encode : function (input) { //인코딩
		var output = "";
		var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
		var i = 0;

		while (i < input.length) {
		  chr1 = input.charCodeAt(i++);
		  chr2 = input.charCodeAt(i++);
		  chr3 = input.charCodeAt(i++);

		  enc1 = chr1 >> 2;
		  enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
		  enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
		  enc4 = chr3 & 63;

		  if (isNaN(chr2)) {
			  enc3 = enc4 = 64;
		  } else if (isNaN(chr3)) {
			  enc4 = 64;
		  }

		  output = output +
			  this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
			  this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);

		}

		return output;
	},

	decode : function (input) { //디코딩
	    var output = "";
	    var chr1, chr2, chr3;
	    var enc1, enc2, enc3, enc4;
	    var i = 0;

	    input = input.replace(/[^A-Za-z0-9+/=]/g, "");

	    while (i < input.length) {
	        enc1 = this._keyStr.indexOf(input.charAt(i++));
	        enc2 = this._keyStr.indexOf(input.charAt(i++));
	        enc3 = this._keyStr.indexOf(input.charAt(i++));
	        enc4 = this._keyStr.indexOf(input.charAt(i++));

			console.log("enc2=" + enc2 + ", &15=>" + (enc2&15));

	        chr1 = (enc1 << 2) | (enc2 >> 4);
	        chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
	        chr3 = ((enc3 & 3) << 6) | enc4;

	        output = output + String.fromCharCode(chr1);

	        if (enc3 != 64) {
	            output = output + String.fromCharCode(chr2);
	        }
	        if (enc4 != 64) {
	            output = output + String.fromCharCode(chr3);
	        }
	    }

	    return output;
	}
}

/******************************************
 //인코딩처리(보안처리용)
******************************************/
function encode(sStr) {
	return Base64.encode(escape(sStr));
}

/******************************************
  이미지파일인지 여부구하기
******************************************/
function isImageFile(sFileName, sImageExts) {
	var sExt = getFileExt(sFileName);
	return hasValue(sImageExts.toLowerCase(), sExt.toLowerCase(), ",");
}


/******************************************
  종료할때 모든팝업 닫기 수행
******************************************/
$(window).bind("unload", function() {
	popCloseAll();
});

/******************************************
 elemenet list데이터에서 foreach -> attr 가공하여 리턴처리
-------------------------------------------
2018/06/29 주지호
-------------------------------------------
<인자>
$items : foreach 대상 jquery리스트배열
oFnExtractData : 각 $item에 적용할 함수
sDataType : 최종리턴 데이터 가공방식
 - json : json 배열로 처리
 - ~~~~ : serializeParam 함수에 적용시킬 인코딩타입
-------------------------------------------
<리턴값>
 rtn.err : 에러가 발생했었는지여부
 rtn.num : flag=M/I 로 설정된 항목의 갯수
 rtn.data : 실제 가공한 리턴데이터
******************************************/
function getIOData($Items, oFnExtractData, sDataType) {
	var vRtnData;
	var nNum = 0;
	var bError = false;
	sDataType = sDataType || "escape";
	//리턴형식에 맞게 데이터 초기화
	switch(sDataType) {
		case "json"://JSON 배열
			vRtnData = [];
			break;
		default:// 그 이외의 경우에는 객체직렬화(seriazlie)에 곧바로 타입값을 넘긴다
			vRtnData = "";
			break;
	}

	for(var i=0; i<$Items.length; i++) {
		var $o = $Items.eq(i);
		var oData = oFnExtractData($o, (nNum+1));
		if(oData == false) { //에러가 발생하면 break 후 리턴
			bError = true;
			break;
		}
		if(oData) { //리턴된 데이터가 있을때만 처리
			if(oData.flag != "D") { //삭제가 아닌 경우에만
				oData.seq = ++nNum;
			}

			switch(sDataType) {
				case "json": //JSON형태
					vRtnData.push(oData);
					break;
				default: //serializeParam 에 바로 넘기기
					if(vRtnData != "") {
						vRtnData += ",";
					}
					vRtnData += VFUNC.serializeParam(oData, sDataType);
					break;
			}
		}
	}
	return {
		"err"  : bError, //에러가 발생했는지 여부
		"data" : vRtnData, //sDataType에 따라 가공한 리턴데이터
		"num"  : nNum // flag가 I or M 으로 처리된 항목 갯수리턴
	};
}




















































//■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
// 배포수행 관련 ajax호출 함수정의 시작
//■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
/***************************************************
 - 설명 : 각각의 ajax호출 및 리턴처리 공통함수
 - sUrl   : 호출할 대상 URL
 - oFn    : y,n,error 각각의 결과에따른 콜백함수
 - oParam : json형식의 파라미터 (존재할경우 POST로 데이터를 넘긴다)
 - bDebug : 디버깅모드(window.open으로 수행)
***************************************************/
function commonAjaxRequest(sUrl, oFn, oParam, bDebug) {
	if(bDebug == true) { //디버깅모드일때
		if(!oParam) {
			window.open(sUrl);
		}
		else { //포스트는 동적form생성한다
			var $Frm = $("#frmDebug");
			if($Frm.length <= 0) { //폼객체 생성
				var oFrm = document.createElement("FORM");
				oFrm.id = "frmDebug";
				oFrm.method = "POST";
				oFrm.action = sUrl;
				oFrm.target = "_blank";
				//oFrm.style.display = "none";
				$(document.body).append(oFrm);
				$Frm = $("#frmDebug");
			}

			//기존 엘리컨트 다 날리기
			$Frm.find("input").each(function() {
				$(this).remove();
			});

			//새 파라미터 등록
			for(key in oParam) {
				var $Input = $("<input type='hidden' name='" + key + "'>");
				$Input.val(oParam[key]);
				$Frm.append($Input);
			}
			$Frm.submit();
		}
		return;
	}
	$.ajax({
		"url"      : sUrl,
		"type"     : (oParam ? "POST" : "GET"),
		"dataType" : "json",
		"data"     : (oParam ? serializeParam(oParam, "utf-8") : undefined),
		"success"  : function(jData) {
			if(jData["return"] == "success") {
				if(oFn && oFn.y)
					oFn.y(jData);
			}
			else {
				if(oFn && oFn.n)
					oFn.n(jData);
			}
		},
		"error"    : function(oXhr) {
			if(oFn && oFn.error)
				oFn.error(oXhr);
		},
		"complete" : function(oXhr, sStatus) {
			if(oFn.after) {
				oFn.after(oXhr, sStatus);
			}
		},
		"beforeSend" : function(oXhr, oSet) {
			if(oFn.before) {
				oFn.before(oXhr, oSet);
			}
		}
	});
}



/******************************************
 - 설명 : 배포수행
 - 참조 : /distribute_do_single.asp
 <파라미터정보>
filepath         : 배포할 파일경로(드라이브/루트경로 제외)
drive_stage      : 스테이지서버 드라이브
root_stage       : 스테이지서버 루트경로
drive_real1      : 운영서버1 드라이브
drive_real2      : 운영서버2 드라이브
root_real1       : 운영서버1 루트경로
root_real2       : 운영서버2 루트경로
tmachine_use     : TMachin 사용여부
tmachine_date    : TMachin 날짜(yyyy-mm-dd)
tmachine_hour    : TMachin 시
tmachine_minute  : TMachin 분
tmachine_second  : TMachin 초
******************************************/
function distributeDo(oParam, oFn, bDebug) {
	var sUrl = "/common/ajax/distribute_do_single.asp";
	commonAjaxRequest(sUrl, oFn, oParam, bDebug);
}



/******************************************
 - 설명 : 파일 텍스트로 저장
 - 참조 : /text_save.asp
 <파라미터정보>
 server   : 서버정보객체,
 filepath : 파일경로,
 text     : 저장할 텍스트,
 encoding : 인코딩

  sFilePath : 파일 저장할 경로(풀 물리경로)
  sText     : 저장할 텍스트내용
  sEncoding : 저장할 인코딩(EUC-KR, UTF-8, UTF-8+BOM))
******************************************/
function fileSave(oParam, oFn, bDebug) {
	var sUrl = "/common/ajax/text_save.asp";
	commonAjaxRequest(sUrl, oFn, oParam, bDebug);
}



/******************************************
 - 설명 : 백업수행
 - 참조 : /backup_do_single.asp

 <파라미터정보>
src_drive        : 백업소스 드라이브
src_root         : 백업소스 루트경로
filepath         : 백업소스 파일위치(드라이브,루트경로 제외)
trg_drive        : 백업저장 드라이브
trg_root         : 백업저장 루트
backup_ext       : 백업확장자
backup_imagetype : 이미지 백업정보(bak폴더로 할지, 일괄생성할지)
******************************************/
function backupDo(oParam, oFn, bDebug) {
	var sUrl = "/common/ajax/backup_do_single.asp";
	commonAjaxRequest(sUrl, oFn, oParam, bDebug);
}



/******************************************
 - 설명 : 파일소스 불러오기
 - 참조 : /load_source.asp

 <파라미터정보>
path : 파일경로
encoding : 불러올 인코딩
******************************************/
function loadSource(oParam, oFn, bDebug) {
	var sUrl = "/common/ajax/load_source.asp?" + serializeParam(oParam);
	commonAjaxRequest(sUrl, oFn, oParam, bDebug);
}



/******************************************
 - 설명 : 파일삭제
 - 참조 : /file_delete_single.asp

 <파라미터정보>
filepath : 삭제할 파일 풀경로
******************************************/
function fileDelete(oParam, oFn, bDebug) {
	var sUrl = "/common/ajax/file_delete_single.asp" ;
	commonAjaxRequest(sUrl, oFn, oParam, bDebug);
}






/******************************************
 - 설명 : 파일복사(백업 용도로 사용)
 - 참조 : /file_copy_single.asp

 <파라미터정보>
from     : {
	//복사해서 가져올 원본서버의 연결정보,
	filepath : 복사할 파일 풀경로
},
to      : {
	//붙여넣을 대상서버의 연결정보,
	filepath : 붙여넣을 파일 풀경로
}

******************************************/
function fileCopy(oParam, oFn, bDebug) {
	var sUrl = "/common/ajax/file_copy_single.asp" ;
	commonAjaxRequest(sUrl, oFn, oParam, bDebug);
}




/******************************************
 - 설명 : 파일체크(소스서버와, 운영서버배열의 파일정보 리턴)
 - 참조 : /file_check_single.asp

 <파라미터정보>
filepath    : 파일경로
srcserver   : {
	//환경설정의 소스서버정보,
	"root"  : 서비스루트경로
},
realserver  : [{
	//환경설정의 운영서버[0]정보,
	"root"  : 서비스루트경로
}, {~~}]
******************************************/
function fileCheckDo(oParam, oFn, bDebug) {
	var sUrl = "/common/ajax/file_check_single.asp";
	commonAjaxRequest(sUrl, oFn, oParam, bDebug);
}

/******************************************
 - 설명 : 파일의 서브리스트 체크후 리턴
 - 참조 : /file_check_sublist_single.asp

 <파라미터정보>
filepath    : 파일경로(루트경로)
server   : {
	//환경설정의 소스서버정보,
	"root"  : 서비스루트경로
},
******************************************/
function fileCheckSublistDo(oParam, oFn, bDebug) {
	var sUrl = "/common/ajax/file_check_sublist.asp";
	commonAjaxRequest(sUrl, oFn, oParam, bDebug);
}


/******************************************
 - 설명 : 환경설정 불러오기
 - 참조 : /env.asp

 <파라미터정보>
 없음
******************************************/
function getEnv(oFn, oParam, bDebug) {
	var sUrl = "/common/ajax/env_load.asp";
	commonAjaxRequest(sUrl, oFn, oParam, bDebug);
}
//■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
// 배포수행 관련 ajax호출 함수정의 끝
//■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
