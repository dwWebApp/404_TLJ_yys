<?php
include_once $_SERVER["DOCUMENT_ROOT"] . "/common/php/header.php";
include_once $_SERVER["DOCUMENT_ROOT"] . "/common/php/functions.php";
include_once $_SERVER["DOCUMENT_ROOT"] . "/common/php/class.CLASS_FTP.php";


//XMl출력
function writeXML($sBody) {
	Header("Content-Type: text/xml; charset=UTF-8");
	echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>";
	echo $sBody;
}

/*■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
 단일 파일정보 조회
 <?xml version="1.0" encoding="UTF-8" standalone="yes">
 <fileinfo>
	<filedate></filedate>
	<filesize></filesize>
 </fileinfo>
■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■*/
if($_POST["flag"] == "fileinfo") {

//	printReq();
//	exit;
	//FTP연결 시작
	$oFtp       = new CLASS_FTP();
	$oFtp->ip   = $_POST["ftp_ip"];
	$oFtp->port = $_POST["ftp_port"];
	$oFtp->id   = $_POST["ftp_id"];
	$oFtp->pw   = $_POST["ftp_pw"];
	$oFtp->gmt  = (int)$_POST["ftp_gmt"];
	$oFtp->enc  = $_POST["ftp_enc"];
	$oFtp->connect();
	if($_POST["ftp_type"] == "PASV")
		$oFtp->set_passive(true);
	else
		$oFtp->set_passive(false);



	//파일정보 get
	$nFileByte = $oFtp->size($_POST["fullpath"]); //일단 파일크기를 체크하자
//	echo "filebyte=" . $nFileByte;
	if($nFileByte >= 0) { //(파일이면 >-1리턴, 폴더면 -1리턴한다)
		$sFileDate = $oFtp->mdtm($_POST["fullpath"]); //날짜 get
		$aFileInfo = $oFtp->rawlist($_POST["fullpath"]);
		if(sizeof($aFileInfo) > 0) {
			$sType = $oFtp->getDirLineFDType($aFileInfo[0]);
			switch($sType) { //윈도우파일/리눅스파일 형식인 경우에만 처리 ㄱㄱ
				case "UF":
				case "WF":
					$oFtp->parseDirLine($aFileInfo[0], $sFileDate, $sFileSize, $sFileName, $sType);
					break;
			}
		}
	}
	$oFtp->disconnect();

	$sXML  = "";
	$sXML .= "<fileinfo>";
	$sXML .= "<filename><![CDATA[" . $sFileName . "]]></filename>";
	$sXML .= "<filesize><![CDATA[" . $nFileByte . "]]></filesize>";
	$sXML .= "<filedate><![CDATA[" . ($sFileDate > 0 ? date("Y-m-d H:i:s", $sFileDate) : ""). "]]></filedate>";
	$sXML .= "</fileinfo>";
	writeXML($sXML);
}



/*■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
 폴더내 서브목록 조회
  <?xml version="1.0" encoding="UTF-8" standalone="yes">
 <filelist>
	<flie>
		<fullpath></fullpath>
	</file>
	<flie>
		<fullpath></fullpath>
	</file>
	<flie>
		<fullpath></fullpath>
	</file>
 </filelist>
■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■*/
else if($_POST["flag"] == "filesublist") {

	//FTP연결 시작
	$oFtp       = new CLASS_FTP();
	$oFtp->ip   = $_POST["ftp_ip"];
	$oFtp->port = $_POST["ftp_port"];
	$oFtp->id   = $_POST["ftp_id"];
	$oFtp->pw   = $_POST["ftp_pw"];
	$oFtp->gmt  = (int)$_POST["ftp_gmt"];
	$oFtp->enc  = $_POST["ftp_enc"];
	$oFtp->connect();
	if($_POST["ftp_type"] == "PASV")
		$oFtp->set_passive(true);
	else
		$oFtp->set_passive(false);

	if(right($_POST["fulldir"], 1) != "\\") {
		$_POST["fulldir"] .= "\\";
	}

	//폴더정보 get
	$aPath = $oFtp->parseDirSubList($_POST["fulldir"]);
	$sXML  = "";
	$sXML .= "<filelist>";
	foreach($aPath as $sFilePath) {
		$sXML .= "<file>";
		$sXML .= "<fullpath><![CDATA[" . $sFilePath . "]]></fullpath>";
		$sXML .= "</file>";
	}
	$sXML .= "</filelist>";
	writeXML($sXML);
}


/*■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
 폴더내 1depth 하위폴더만 조회
  <?xml version="1.0" encoding="UTF-8" standalone="yes">
 <folderlist>
	<folder>
		<folderpath></folderpath>
	</folder>
	<folder>
		<folderpath></folderpath>
	</folder>
	<folder>
		<folderpath></folderpath>
	</folder>
 </folderlist>
■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■*/
else if($_POST["flag"] == "filebackuplist") {
	
	//FTP연결 시작
	$oFtp       = new CLASS_FTP();
	$oFtp->ip   = $_POST["ftp_ip"];
	$oFtp->port = $_POST["ftp_port"];
	$oFtp->id   = $_POST["ftp_id"];
	$oFtp->pw   = $_POST["ftp_pw"];
	$oFtp->gmt  = (int)$_POST["ftp_gmt"];
	$oFtp->enc  = $_POST["ftp_enc"];
	$oFtp->connect();
	if($_POST["ftp_type"] == "PASV")
		$oFtp->set_passive(true);
	else
		$oFtp->set_passive(false);

	//폴더정보 get(하위 1depth 폴더까지만)
	$aPath = $oFtp->parseDir1Depth($_POST["fulldir"]);
	$sXML  = "";
	$sXML .= "<folderlist>";
	foreach($aPath as $sFolderpath) {
		$sXML .= "<folder>";
		$sXML .= "<folderpath><![CDATA[" . $sFolderpath . "]]></folderpath>";
		$sXML .= "</folder>";
	}
	$sXML .= "</folderlist>";
	writeXML($sXML);
}





/*■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
 파일 다운로드
■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■*/
else if($_POST["flag"] == "get") {
//	printReq();
//	exit;
	//FTP연결 시작
	$oFtp       = new CLASS_FTP();
	$oFtp->ip   = $_POST["ftp_ip"];
	$oFtp->port = $_POST["ftp_port"];
	$oFtp->id   = $_POST["ftp_id"];
	$oFtp->pw   = $_POST["ftp_pw"];
	$oFtp->gmt  = (int)$_POST["ftp_gmt"];
	$oFtp->enc  = $_POST["ftp_enc"];
	$oFtp->connect();
	if($_POST["ftp_type"] == "PASV")
		$oFtp->set_passive(true);
	else
		$oFtp->set_passive(false);

	$oFtp->get($_POST["srcpath"], $_POST["trgpath"]);
}



/*■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
 파일 업로드 - 파일정보와 동일한 XML리턴
<?xml version="1.0" encoding="UTF-8" standalone="yes">
<fileinfo>
	<filedate></filedate>
	<filesize></filesize>
</fileinfo>
■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■*/
else if($_POST["flag"] == "put") {
	//FTP연결 시작
	$oFtp       = new CLASS_FTP();
	$oFtp->ip   = $_POST["ftp_ip"];
	$oFtp->port = $_POST["ftp_port"];
	$oFtp->id   = $_POST["ftp_id"];
	$oFtp->pw   = $_POST["ftp_pw"];
	$oFtp->gmt  = (int)$_POST["ftp_gmt"];
	$oFtp->enc  = $_POST["ftp_enc"];
	$oFtp->connect();
	if($_POST["ftp_type"] == "PASV")
		$oFtp->set_passive(true);
	else
		$oFtp->set_passive(false);

	//폴더가 없는 경우가 존재할 수 있으므로, 폴더생성을 먼저 수행한 후 업로드한다
	// - window FTP의 경우, 상위폴더가 존재하지 않을때 서브폴더까지 한번에 생성이 안되므로,....
	//   상위폴더부터 차례대로 생성한다
	/*
	$sPath = pathinfo($_POST["trgpath"], PATHINFO_DIRNAME);
	$aDir = explode("\\", $sPath);
	$sCurPath = "";
	foreach($aDir as $sDir) {
		if($sDir != "") {
			$sCurPath .= "\\" . $sDir;
			$oFtp->mkdir($sCurPath);
		}
	}
	*/
	
	$oFtp->put($_POST["srcpath"], $_POST["trgpath"]); //put 수행

	//업로드완료 후 업로드된 파일 정보를 XML로 생성하여 리턴한다
	$nFileByte = $oFtp->size($_POST["fullpath"]); //일단 파일크기를 체크하자
	if($nFileByte > 0) { //항목이 존재한다면 파일크기 값이 나오므로, 그다음을 체크한다
		$sFileDate = $oFtp->mdtm($_POST["fullpath"]); //날짜
		$aFileInfo = $oFtp->rawlist($_POST["fullpath"]);
		if(sizeof($aFileInfo) > 0) {
			$sType = $oFtp->getDirLineFDType($aFileInfo[0]);
			switch($sType) { //파일인 경우에만 체크 ㄱㄱ
				case "UF":
				case "WF":
					$oFtp->parseDirLine($aFileInfo[0], $sFileDate, $sFileSize, $sFileName, $sType);
					break;
			}
		}
	}
	$oFtp->disconnect();

	$sXML  = "";
	$sXML .= "<fileinfo>";
	$sXML .= "<filename><![CDATA[" . $sFileName . "]]></filename>";
	$sXML .= "<filesize><![CDATA[" . $nFileByte . "]]></filesize>";
	$sXML .= "<filedate><![CDATA[" . ($sFileDate > 0 ? date("Y-m-d H:i:s", $sFileDate) : ""). "]]></filedate>";
	$sXML .= "</fileinfo>";
	writeXML($sXML);
}
else {
	echo "파라미터불량 오류";
}
?>