<?php
include_once $_SERVER["DOCUMENT_ROOT"] . "/common/php/header.php";
include_once $_SERVER["DOCUMENT_ROOT"] . "/common/php/functions.php";


//XMl출력
function writeXML($sBody) {
	Header("Content-Type: text/xml; charset=UTF-8");
	echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>";
	echo $sBody;
}

/*■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  - 바이너리 파일을 base64 인코딩
<?xml version="1.0" encoding="UTF-8" standalone="yes">
<result>
	<body> base64인코딩문자 </body>
</result>
■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■*/
if($_POST["flag"] == "base64encode_file") {
	$sBody = "";
	$sFilePath = $_POST["filepath"];
	if($sFilePath != "") {
		if(file_exists($sFilePath)) {
			$sBody = base64_encode(file_get_contents($sFilePath));
		}
	}

	$sXml = "";
	$sXml .= "<result>";
	$sXml .= "<body><![CDATA[" . $sBody . "]]></body>";
	$sXml .= "</result>";
	writeXML($sXml);
}
else if($_POST["flag"] == "base64decode") {
	$sText = $_POST["text"];
	$sXml = "";
	$sXml .= "<result>";
	$sXml .= "<body><![CDATA[" . base64_decode($sText) . "]]></body>";
	$sXml .= "</result>";
	writeXML($sXml);
}
else {
	echo "파라미터불량 오류";
}
?>