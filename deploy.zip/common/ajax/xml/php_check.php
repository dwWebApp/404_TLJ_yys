<?php
/*****************************************
 PHP 연동 체크
*****************************************/
$aData = array();
$aData["return"] = "success";
$aData["data"]   = null;
echo json_encode($aData);
?>