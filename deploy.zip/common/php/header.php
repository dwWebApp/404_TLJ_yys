<?php
//공통헤더 설정
Header("Content-Type: text/html; charset=UTF-8");
Header("Cache-Control", "no-cache, must-revalidate");
Header("Pragma", "no-cache");

ini_set("display_errors", 1);
//error_reporting(E_ALL);
error_reporting(E_ERROR);
set_time_limit(600);
?>
