<?php
/**********************************************
 FTP 제어 클래스
***********************************************/
class CLASS_FTP {
	private $ip, $id, $pw;
	private $gmt  = 0; //GTM시간차이
	private $port = "21";
	private $objFTP;
	private $enable = false;
	private $enc;


	//생성자
	public function __construct() {
	}
	
	//파괴자
	public function __destruct() {
		if($this->objFTP) {
			$this->Disconnect();
		}
	}

	//getter
	public function __get($sName) {
		return $this->$sName;
	}

	//setter
	public function __set($sName, $sValue) {
		$this->$sName = $sValue;
	}



	/******************************************
	  public 메서드정의 시작
	******************************************/
	//서버타입에 따라, 파일인지/ 디렉토리인지 여부 리턴(F/D)
	public function getDirLineFDType($sLine, $sOs = null) {
		if(substr($sLine, 0, 1) == "d" ) { //유닉스 디렉토리
			return "UD";
		}
		else if(substr($sLine, 0, 1) == "-" ) { //유닉스 파일
			return "UF";
		}
		else if(strpos($sLine, "<DIR>")) { //윈도우 디렉토리
			return "WD";
		}
		else { //그렇지않으면 윈도우 파일로 간주
			return "WF";
		}
		
	}

	//라인 한줄을 읽어 데이터 리턴한다
	// &sFileDate : 날짜
	// &sFileSize : 크기
	// &sDataName : 파일/폴더 명
	public function parseDirLine($sLine, &$sFileDate, &$sFileSize, &$sDataName, $sType) {
		$aInfo = explode(" ", $sLine);
		$nCnt = 0;
		$nPos = 0;

		if($sType == "UD" || $sType == "UF") { //유닉스 파일/디렉토리
			foreach($aInfo as $val) {
				
				if($val != "") { //값이 있는경우에
					$nCnt++;
				}

				//각 단계별로 파싱
				//유닉스파일 / 유닉스폴더 (동일한 리턴구조) -> '1.권한구조, 2.??,  3.소유자, 4.그룹, 5.크기, 6.월, 7.일, 8.시간, 9-파일/폴더명
				switch($nCnt) {
					case 5:	//파일크기
						$nPos += strlen($val);
						$sFileSize = $val;
						break;
					case 9://파일명
						$sDataName = substr($sLine, $nPos);
						$nPos += strlen($val);
						break;
					default:
						$nPos += strlen($val);
				}
				$nPos++;
			}
		}
		else if($sType == "WF" || $sType == "WD") { //윈도우 파일/디렉토리
			foreach($aInfo as $val) {
				if($val != "") { //값이 있는경우에
					$nCnt++;
				}

				//각 단계별로 파싱
				//윈도우 파일/폴더 -> '순서 : 1-날짜,  2-시간,  3-<DIR>/용량,  4-파일/폴더명
				switch($nCnt) {
					case 3: //DIr or 용량
						$nPos += strlen($val);
						$sFileSize = $val;
						break;
					case 4:	//파일/폴더 명
						$sDataName = substr($sLine, $nPos);
						$nPos += strlen($val);
						break;
					default:
						$nPos += strlen($val);
				}
				$nPos++;
			}
		}

		//파일/폴더명을 찾았을 경우, 인코딩을 체크하여 UTF-8로 변환한다
		if($sDataName != "") {
			$sDataName = $this->enc_output($sDataName);
		}
	}

	//서브목록 파일 전체 리스트배열로 리턴
	public function parseDirSubList($sFullDir) {
		$aList = $this->rawlist($sFullDir);
		$aReturn = array();
		foreach($aList as $sLine) {
			$sType = $this->getDirLineFDType($sLine);
			$this->parseDirLine($sLine, $sFileDate, $sFileSize, $sDataName, $sType);

			switch($sType) {
				case "WF": //윈도우 파일
				case "UF": //유닉스 파일
					//파일이라면 파싱한 정보를 배열에 담는다
					$sFilePath = $sFullDir . $sDataName;
					array_push($aReturn, $sFilePath); //파일정보 배열에 push
					break;

				case "WD": //윈도우 폴더
				case "UD": //유닉스 폴더
					//디렉토리라면 재귀호출한다
					if($sDataName != "") //잘못된 인코딩 설정시 리턴값이 없어, 무한재귀호출이 발생되는것을 막기위한 설정
						$aReturn = array_merge($aReturn, $this->parseDirSublist($sFullDir . $sDataName . "\\"));
					break;
			}
		}
		return $aReturn;
	}

	//1depth 하위의 디렉토리만 파싱
	public function parseDir1Depth($sFullDir) {
		$aList = $this->rawlist($sFullDir);
		$aReturn = array();
		foreach($aList as $sLine) {
			$sType = $this->getDirLineFDType($sLine);
			$this->parseDirLine($sLine, $sFileDate, $sFileSize, $sDataName, $sType);

			switch($sType) {
				case "WF": //윈도우 파일
				case "UF": //유닉스 파일
					//폴더정보만 필요하므로 파일은 패스
					break;

				case "WD": //윈도우 폴더
				case "UD": //유닉스 폴더
					array_push($aReturn, $sDataName); //폴더정보 담기
					break;
			}
		}
		return $aReturn;
	}
	
	
	
	//------------FTP 함수 direct호출용 정의부분------------
	//OS타입 정보
	public function systype() {
		if($this->enable) {
			return ftp_systype($this->objFTP);
		}
		return "";
	}

	//raw리스트
	public function rawlist($sPath) {
		if($this->enable) {
			return ftp_rawlist($this->objFTP, $this->enc_input($sPath));
		}
		return array();
	}

	//리스트 ㄱㄱ
	public function nlist($sFilePath) {
		if($this->enable) {
			return ftp_nlist($this->objFTP, $this->enc_input($sPath));
		}
		return false;
	}

	//파일 마지막 수정날짜 가져오기(단일파일)
	public function mdtm($sPath) {
		if($this->enable) {
			$sRtn = (int)ftp_mdtm($this->objFTP, $this->enc_input($sPath));
			if($sRtn > 0) {
				$sRtn += (3600*$this->gmt); //타임존 GMT만큼 시간+시킨다
			}
			return $sRtn;
		}
		return false;
	}

	//파일사이즈 가져오기(단일파일)
	public function size($sPath) {
		if($this->enable) {
			$sSize = (int)ftp_size($this->objFTP, $this->enc_input($sPath));
			return $sSize;
		}
		return false;
	}

	//디렉토리생성
	public function mkdir($sPath) {
		if($this->enable) {
			// - window FTP의 경우, 상위폴더가 존재하지 않을때 서브폴더까지 한번에 생성이 안되므로,....
			//   상위폴더부터 차례대로 생성해 나가는 방식으로 처리한다
			$sPath = str_replace("/", "\\", $sPath);
			$aDir = explode("\\", $sPath);
			$sCurPath = "";
			foreach($aDir as $sDir) {
				if($sDir != "") {
					$sCurPath .= "\\" . $sDir;
					ftp_mkdir($this->objFTP, $this->enc_input($sCurPath));
				}
			}
			return true;
		}
		return false;
	}

	//파일 다운로드
	public function get($sSrc, $sTrg) {
		if($this->enable) {
			ftp_get($this->objFTP, $sTrg, $this->enc_input($sSrc), FTP_BINARY);
		}
		return false;
	}

	//파일업로드
	public function put($sSrc, $sTrg) {
		if($this->enable) {
			//폴더가 없는 경우가 존재할 수 있으므로, 폴더생성을 먼저 수행한 후 업로드한다
			// - 기본적으로 모든 로직상 경로문자는 \를 사용하는데
			//   php의 pathinfo 가 \문자 상에서 제대로 작동되지 않아.
			//   임시로 `\ -> /` 변환하여 사용한다
			$sTrg = str_replace("\\", "/", $sTrg);
			$this->mkdir(pathinfo($sTrg, PATHINFO_DIRNAME));
			$sTrg = str_replace("/", "\\", $sTrg);
			return ftp_put($this->objFTP ,$this->enc_input($sTrg), $sSrc, FTP_BINARY);
		}
		return false;
	}

	//패시브모드 설정
	public function set_passive($bVal) {
		if($this->enable) {
			return ftp_pasv($this->objFTP, $bVal);
		}
		return false;
	}

	//연결
	public function connect() {
		if($this->objFTP) {
			$this->Disconnect();
		}
		$this->objFTP = ftp_connect($this->ip, $this->port);
		if(ftp_login($this->objFTP, $this->id, $this->pw) == 1) { //로그인성공시
			$this->enable = true;
		}
		return $this->enable;
	}

	//로그아웃
	public function disconnect() {
		if($this->objFTP) {
			ftp_close($this->objFTP);
			unset($this->objFTP);
		}
		$this->enable = false;
	}
	/******************************************
	  public 메서드정의 끝
	******************************************/






	/******************************************
	  private 메서드정의 시작
	******************************************/
	private function enc_input($sStr) { //ftp에 명령을 날리기한 인코딩변환
		if($this->enc != "UTF-8") {
			$sStr = iconv("UTF-8", $this->enc, $sStr);
		}
		$sStr = str_replace("\\", "/", $sStr);
		return $sStr;
	}

	private function enc_output($sStr) {//ftp로부터 리턴받은 값 인코딩변환
		if($this->enc != "UTF-8") {
			$sStr = iconv($this->enc, "UTF-8", $sStr);
		}
		return $sStr;
	}
	/******************************************
	  private 메서드정의 끝
	******************************************/
}
?>