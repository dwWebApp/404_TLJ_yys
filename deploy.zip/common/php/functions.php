<?php
//함수정의

/*******************************
request데이터 모두 출력
*******************************/
function printReq() {
	echo "<b>POST</b><BR>";
	foreach($_POST as $key=>$val) {
		echo $key . " = " . $val . "<BR>";
	}

	echo "<b>GET</b><BR>";
	foreach($_GET as $key=>$val) {
		echo $key . " = " . $val . "<BR>";
	}

}

/*******************************
오른쪽 len만큼 잘라내기
*******************************/
function right($sStr, $nLen) {
	return substr($sStr, strlen($sStr)-$nLen);
}
?>